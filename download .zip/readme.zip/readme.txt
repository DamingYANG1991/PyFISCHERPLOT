Name of Code: PyFISCHERPLOT.
Title of the Manuscript: PyFISCHERPLOT: A new Python code for constructing Fischer plots based on paleoenvironmental indicator data in batches
"Authors: Daming Yang, Yongjian Huang, Zongyang Chen, Qinghua Huang, Yanguang Ren, Chengshan Wang."
