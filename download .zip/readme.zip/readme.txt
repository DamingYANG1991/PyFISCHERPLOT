Name of Code: PyFISCHERPLOT.
Title of the Manuscript: PyFISCHERPLOT: A new Python code for graphing Fischer plots based on geological data in batches
"Authors: Daming Yang, Yongjian Huang, Zongyang Chen, Qinghua Huang, Yanguang Ren, Chengshan Wang."
